<?php

//function _wptoolset_forms_dependencies_conditional() {
////    require_once WPCF_EMBEDDED_ABSPATH . '/common/functions.php';
////    require_once WPCF_EMBEDDED_ABSPATH . '/common/wplogger.php';
////    require_once WPCF_EMBEDDED_ABSPATH . '/common/wpv-filter-date-embedded.php';
//}